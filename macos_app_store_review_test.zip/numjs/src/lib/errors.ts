"use strict";

export class ValueError extends Error {}
export class ConfigError extends Error {}
export class NotImplementedError extends Error {}
