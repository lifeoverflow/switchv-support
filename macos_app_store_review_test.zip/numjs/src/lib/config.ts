"use strict";

export default {
  printThreshold: 7,
  nFloatingValues: 5,
};
