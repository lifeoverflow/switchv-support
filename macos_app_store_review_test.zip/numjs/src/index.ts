import * as nj from "./lib";
export default nj;
export { NdArray, ndarray } from "./lib";
