const solution = require('./solution');

test('test twoSquare', () => {
  expect(solution(-4, 1, 2, 6, 0, -1, 4, 3)).toBe(42);
});
