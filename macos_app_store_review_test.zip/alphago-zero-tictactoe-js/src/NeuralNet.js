export class NeuralNet {
  constructor() {
    console.log('NeuralNet constructer');
  }
}

