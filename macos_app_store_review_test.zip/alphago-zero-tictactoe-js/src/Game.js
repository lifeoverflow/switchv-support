export class Game {
  constructor() {
    console.log('Game constructer');
  }
}

